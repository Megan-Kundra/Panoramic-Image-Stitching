import cv2
import numpy as np
import matplotlib.pyplot as plt
import random


# Used in Step 3 to match descriptors between images
def match_descriptors_sift(desc1, desc2):
    bf = cv2.BFMatcher(cv2.NORM_L2, crossCheck=True)
    matches = bf.match(desc1, desc2)
    matches = sorted(matches, key=lambda x: x.distance)
    return matches

def compute_affine(src_pts, dst_pts):
    return cv2.getAffineTransform(np.float32(dst_pts), np.float32(src_pts))

# Step 5 (RANSAC implmentation for affine transforms to align images)
def custom_ransac_affine(kp1, kp2, matches, threshold=4.0, iterations=1000):
    best_inliers = []
    best_affine = None
    src_pts_all = np.float32([kp1[m.queryIdx].pt for m in matches])
    dst_pts_all = np.float32([kp2[m.trainIdx].pt for m in matches])

    for _ in range(iterations):
        idx = random.sample(range(len(matches)), 3)
        src_sample = src_pts_all[idx]
        dst_sample = dst_pts_all[idx]

        affine = compute_affine(src_sample, dst_sample)
        dst_transformed = cv2.transform(dst_pts_all.reshape(-1, 1, 2), affine).reshape(-1, 2)

        errors = np.linalg.norm(src_pts_all - dst_transformed, axis=1)
        inliers = np.where(errors < threshold)[0]

        if len(inliers) > len(best_inliers):
            best_inliers = inliers
            best_affine = affine

    if best_affine is None:
        return None, [], None

    # Step 7 (Compute final residuals)
    final_dst = cv2.transform(dst_pts_all[best_inliers].reshape(-1, 1, 2), best_affine).reshape(-1, 2)
    residuals = np.linalg.norm(src_pts_all[best_inliers] - final_dst, axis=1) ** 2
    mean_residual = np.mean(residuals)
    print(f"Custom RANSAC (Affine): {len(best_inliers)} inliers, {len(matches) - len(best_inliers)} outliers")
    print(f"Mean squared residual (inliers): {mean_residual:.2f}")

    return best_affine, best_inliers, matches

# Visualize the inliers between the two images
def draw_affine_inliers(image1, image2, kp1, kp2, matches, inlier_indices):
    inlier_matches = [matches[i] for i in inlier_indices]
    matched_img = cv2.drawMatches(image1, kp1, image2, kp2, inlier_matches, None, flags=2)
    cv2.imshow("Affine Inlier Matches", matched_img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

# Used to sharpen the overlapping region of the stitched image after blending
def sharpen_region(img, mask):
    kernel = np.array([[0, -1, 0],
                       [-1, 5, -1],
                       [0, -1, 0]], dtype=np.float32)
    sharpened_img = cv2.filter2D(img, -1, kernel)
    sharpened_img[mask == 1] = img[mask == 1]
    return sharpened_img

# blend the overlapping region of the stitched image
def blend_images(img1, img2):
    mask1 = (img1 > 0).astype(np.uint8)
    mask2 = (img2 > 0).astype(np.uint8)

    dist1 = cv2.distanceTransform(cv2.cvtColor(mask1 * 255, cv2.COLOR_BGR2GRAY), cv2.DIST_L2, 3)
    dist2 = cv2.distanceTransform(cv2.cvtColor(mask2 * 255, cv2.COLOR_BGR2GRAY), cv2.DIST_L2, 3)

    dist_sum = dist1 + dist2 + 1e-6
    weight1 = dist1 / dist_sum
    weight2 = dist2 / dist_sum

    weight1_3c = cv2.merge([weight1] * 3)
    weight2_3c = cv2.merge([weight2] * 3)

    blended = (img1.astype(np.float32) * weight1_3c + img2.astype(np.float32) * weight2_3c).astype(np.uint8)
    return blended

# Step 6 (Warp image 2 onto image 1, stitch images togther)
def stitch_affine(image1, image2, affine):
    h1, w1 = image1.shape[:2]
    h2, w2 = image2.shape[:2]
    panorama_width = w1 + w2
    panorama_height = max(h1, h2)

    # Warp image 2's perspective onto the panorama canvas to match image 1
    warped_image2 = cv2.warpAffine(image2, affine, (panorama_width, panorama_height))
    base = np.zeros((panorama_height, panorama_width, 3), dtype=np.uint8)
    base[:h1, :w1] = image1

    blended = blend_images(base, warped_image2)
    gray_blended = cv2.cvtColor(blended, cv2.COLOR_BGR2GRAY)
    _, thresh = cv2.threshold(gray_blended, 1, 255, cv2.THRESH_BINARY)
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    if contours:
        all_points = np.vstack([c.reshape(-1, 2) for c in contours])
        x, y, w, h = cv2.boundingRect(all_points)
        if w > 50 and h > 50:
            blended = blended[y:y+h, x:x+w]
        else:
            print(f"[Warning] Cropped region too small (w={w}, h={h}) — keeping original blended.")
    else:
        print("[Warning] No valid contours found — skipping crop.")

    # Inpaint small black regions remaining after cropping
    gray_final = cv2.cvtColor(blended, cv2.COLOR_BGR2GRAY)
    black_mask = (gray_final == 0).astype(np.uint8) * 255
    kernel = np.ones((5, 5), np.uint8)
    black_mask_dilated = cv2.dilate(black_mask, kernel, iterations=1)
    blended = cv2.inpaint(blended, black_mask_dilated, inpaintRadius=7, flags=cv2.INPAINT_TELEA)

    mask_blend = np.zeros_like(blended[:, :, 0])
    black_mask_expanded = cv2.merge([black_mask] * 3)
    mask_blend[(black_mask_expanded[:, :, 0] == 0) & (blended > 0).all(axis=-1)] = 1
    blended = sharpen_region(blended, mask_blend)

    print(f"[Info] Final stitched size: {blended.shape}")
    return blended


# Step 1 & 2 (compute SIFT keypoints and descriptors)
def detect_and_compute_sift(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    sift = cv2.SIFT_create()
    keypoints, descriptors = sift.detectAndCompute(gray, None)
    return keypoints, descriptors

# Step 7 (Sensitivity analysis with various thresholds)
def sensitivity_analysis_with_accuracy(image1, image2):
    thresholds = [2, 3, 4, 5, 6]
    inlier_counts = []
    mean_residuals = []

    # Step 1 & 2: Compute SIFT features
    kp1, desc1 = detect_and_compute_sift(image1)
    kp2, desc2 = detect_and_compute_sift(image2)

    # Step 3: Match descriptors
    matches = match_descriptors_sift(desc1, desc2)

    for t in thresholds:
        # Step 5: RANSAC with varying inlier threshold
        affine_matrix, inlier_indices, _ = custom_ransac_affine(kp1, kp2, matches, threshold=t, iterations=1000)

        if affine_matrix is None or len(inlier_indices) == 0:
            inlier_counts.append(0)
            mean_residuals.append(np.inf)
            continue

        # Compute mean residual for inliers
        src_pts_all = np.float32([kp1[m.queryIdx].pt for m in matches])
        dst_pts_all = np.float32([kp2[m.trainIdx].pt for m in matches])
        final_dst = cv2.transform(dst_pts_all[inlier_indices].reshape(-1, 1, 2), affine_matrix).reshape(-1, 2)
        residuals = np.linalg.norm(src_pts_all[inlier_indices] - final_dst, axis=1)
        mean_residual = np.mean(residuals)

        inlier_counts.append(len(inlier_indices))
        mean_residuals.append(mean_residual)

    # Plotting
    plt.figure(figsize=(12, 5))

    plt.subplot(1, 2, 1)
    plt.plot(thresholds, inlier_counts, marker='o', color='blue')
    plt.title('Inliers vs. RANSAC Threshold')
    plt.xlabel('Threshold')
    plt.ylabel('Inlier Count')
    plt.grid(True)

    plt.subplot(1, 2, 2)
    plt.plot(thresholds, mean_residuals, marker='x', color='green')
    plt.title('Residual Error vs. RANSAC Threshold')
    plt.xlabel('Threshold')
    plt.ylabel('Mean Residual Error')
    plt.grid(True)

    plt.tight_layout()
    plt.show()



if __name__ == "__main__":

    # *** Load your images here ***
    image1 = cv2.imread("leftImage.png")
    image2 = cv2.imread("rightImage.png")
    # Check if images are loaded successfully
    if image1 is None or image2 is None:
        raise FileNotFoundError("One or both images could not be loaded.")

    # Step 1 & 2 (compute SIFT keypoints and descriptors)
    kp1, desc1 = detect_and_compute_sift(image1)
    kp2, desc2 = detect_and_compute_sift(image2)

    # Step 3 & 4 (match descriptors & find their distances)
    matches = match_descriptors_sift(desc1, desc2)

    # Step 5 (RANSAC implmentation for affine transforms)
    affine_matrix, affine_inliers, affine_matches = custom_ransac_affine(kp1, kp2, matches)

    if affine_matrix is not None:
        # Step 6 (Warp image 2 onto image 1, stitch images togther)
        result_affine = stitch_affine(image1, image2, affine_matrix)
        draw_affine_inliers(image1, image2, kp1, kp2, affine_matches, affine_inliers)
        cv2.imshow("Stitched Panorama (Affine + Blended + Sharpened)", result_affine)
        cv2.waitKey(0)
        cv2.destroyAllWindows()

    # Step 7 (Sensitivity analysis with various thresholds)
    sensitivity_analysis_with_accuracy(image1, image2)